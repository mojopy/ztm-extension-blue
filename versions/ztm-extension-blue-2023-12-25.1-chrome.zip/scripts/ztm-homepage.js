// ----------
// Start Favorite Course Section
// ----------

// ----------
// End Favorite Course Section
// ----------